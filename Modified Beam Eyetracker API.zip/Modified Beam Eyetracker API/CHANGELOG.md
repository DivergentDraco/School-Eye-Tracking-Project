# Beam SDK Changelog

## 1.1.0
2021-08-11

### New Features
* The API can now distinguish between no connection and tracking being lost


## 1.0
2021-07-30

### New Features
* Initial release
